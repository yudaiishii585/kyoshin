# Internal Tool Renewal Kickoff

Date: 2026-02-18  
Time: 16:00-17:20  
Owner: Operations team

## Context
The current internal request form is difficult to maintain. People submit requests by email, Slack, and spreadsheet comments, so status tracking is unreliable.

## Participants
- Ops: Arai, Takeda
- Engineering: Ito, Nishida
- Sales admin: Kuroda

## Discussion
- Arai wants a single intake channel by April 2026.
- Engineering warned that replacing everything at once will take too long.
- Sales admin needs a way to see whether a request is waiting, approved, or rejected.
- The team reviewed examples from 2025, and many requests lacked due dates.

## Decisions
1. Start with a simple request form, not a full workflow system.
2. Required fields: request title, department, due date, reason, approver.
3. Use a spreadsheet for status tracking during the pilot.
4. Review pilot results on 2026年3月18日.

## Action Items
- Takeda: draft the form fields.
- Ito: check authentication requirements.
- Kuroda: provide five real request examples with sensitive details removed.

## Open Questions
- Who closes completed requests?
- Should rejected requests remain visible?
- Is mobile submission required in the first version?
